﻿document.querySelector('.header-logo-image').style.fill = '#FFFFFF';
