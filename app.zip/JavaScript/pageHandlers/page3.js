﻿<!-- Івент DomContentLoaded спрацьовує, коли документ HTML повністю завантажився -->
document.addEventListener("DOMContentLoaded", () => {

    <!-- Видобування кнопок та іншого з сторінки -->
    const colorPicker = document.getElementById("labels-color-picker");
    const colorModal = document.getElementById("color-main");

    const confirmColorsBtn = document.getElementById("confirm-colors" );
    const closeColorBtn = document.getElementById("close-color");

    const nextButton = document.getElementById("next-button");
    const backButton = document.getElementById("back-button");
    const resetButton = document.getElementById("reset-button");

    // Код для вікриття вікна
    colorPicker.addEventListener("click", (event) => {
        event.preventDefault();
        colorModal.style.display = "flex";
    });

    // Код для закриття вікна
    closeColorBtn.addEventListener("click", () => {
        colorModal.style.display = "none";
    });

    // Зберігання вибраних кольорів в змінну та їх підтвердження
    confirmColorsBtn.addEventListener("click", () => {
        const label1Color = document.getElementById("label1-color").value;

        colorPicker.value = label1Color;
        colorModal.style.display = "none";
    });

    // Для кнопок Next i Back
    nextButton.addEventListener("click", () => {
        window.location.href = "../../Assets/HTMLPages/page4.html";
    });
    backButton.addEventListener("click", () => {
        window.location.href = "../../Assets/HTMLPages/page2.html";
    });

    // Для кнопкии скидання введених даних
    resetButton.addEventListener("click", () => {
        document.getElementById("chart-title").value = "";
        document.getElementById("x-axis").value = "";
        document.getElementById("y-axis").value = "";
        document.getElementById("color-picker").value = "#000000";
        document.getElementById("line-style").value = "solid";
    });
});
