﻿import { Chart } from "https://cdn.jsdelivr.net/npm/chart.js";
import {handleFileUpload} from "../modules/fileParser";

let chartInstance;

window.onload = function () {
    const context = document.getElementById("chart").getContext("2d");
    const backButton = document.getElementById("back-button");

    const type = localStorage.getItem("chartType") || "bar";

    const renderChart = (type) => {
        const manualData = JSON.parse(sessionStorage.getItem("manualDataDict")) || { labels: [], values: [] };
        const title = sessionStorage.getItem("TitleOutput") || "Your Chart Name";

        if (chartInstance) {
            chartInstance.destroy();
        }

        chartInstance = new Chart(context, {
            type: type,
            data: {
                labels: manualData.labels,
                datasets: [{
                    label: "Uploaded Data",
                    data: manualData.values,
                    backgroundColor: "rgba(75, 192, 192, 0.2)",
                    borderColor: "rgba(75, 192, 192, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: { size: 25, weight: "bold", family: "Arial" }
                    }
                },
                scales: { y: { beginAtZero: true } }
            }
        });
    };

    renderChart(type);

    backButton.addEventListener("click", () => {
        sessionStorage.removeItem("manualDataDict");
        window.location.href = "../../Assets/HTMLPages/page3.html";
    });
};

export function processFile(file) {
    handleFileUpload(file)
        .then(data => {
            sessionStorage.setItem("manualDataDict", JSON.stringify(data));
            alert("File uploaded successfully.");
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
