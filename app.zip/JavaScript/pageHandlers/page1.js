﻿const fileInput = document.getElementById('file-insert');
const manualDataInput = document.getElementById('manualData');
const nextButton = document.getElementById('next-button');

function checkData() {
    if (fileInput.files.length > 0 || manualDataInput.value.trim() !== "") {
        nextButton.disabled = false; 
    } else {
        nextButton.disabled = true; 
    }
}

fileInput.addEventListener('change', checkData);
manualDataInput.addEventListener('input', checkData);

nextButton.addEventListener('click', () => {
    if (!nextButton.disabled) {
        window.location.href = '../../Assets/HTMLPages/page2.html';
    }
})