﻿import { initializeUI } from './modules/uiHandler.js';

document.querySelector('.header-logo-image').style.fill = '#FFFFFF';
document.addEventListener('DOMContentLoaded', () => {
    initializeUI();
});