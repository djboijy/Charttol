﻿// Публічна змінна для збереження типу чарту
export let currentChartType = null;

// Функції для встановлення відповідного типу чарту в ключову змінну, алежно від того який вибрав користувач
export function renderBarChart() {
    currentChartType = 'bar';
}
export function renderLineChart() {
    currentChartType = 'line';
}
export function renderPieChart() {
    currentChartType = 'pie';
}

// Функція для очищення чарту
export function clearChart(ctx) {
    currentChartType = null; // Скидаємо тип чарту

    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}
