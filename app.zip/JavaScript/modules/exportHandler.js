﻿// html2canvas - бібліотека, яка була використана для експорту
import html2canvas from 'html2canvas';

