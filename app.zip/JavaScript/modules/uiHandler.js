﻿
import { handleFileUpload } from './fileParser.js';
import { renderBarChart, renderLineChart, renderPieChart, clearChart } from './chartRenderer.js';

export function initializeUI() {
    const fileInput = document.getElementById('fileElem');
    const dropArea = document.getElementById('drop-area');
    const generateBtn = document.getElementById('generate-chart');
    const themeToggle = document.getElementById('theme-button');
    
    ;['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    dropArea.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    function handleFiles(files) {
        const file = files[0];
        if (file) {
            handleFileUpload(file)
                .then(data => {
                    // Display data preview
                    displayDataPreview(data);
                })
                .catch(err => {
                    alert(err);
                });
        }
    }

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            handleFiles([file]);
        }
    });

    generateBtn.addEventListener('click', () => {
        // Отримати дані та потім рендернути
    });
}

function displayDataPreview(data) {
    const table = document.getElementById('preview-table');
    table.innerHTML = ''; 
    
    if (data.length === 0) {
        table.innerHTML = '<tr><td>No data available</td></tr>';
        return;
    }
    
    const headers = Object.keys(data[0]);
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    headers.forEach(header => {
        const th = document.createElement('th');
        th.textContent = header;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    const tbody = document.createElement('tbody');
    data.forEach(row => {
        const tr = document.createElement('tr');
        headers.forEach(header => {
            const td = document.createElement('td');
            td.textContent = row[header];
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
    table.appendChild(tbody);
}