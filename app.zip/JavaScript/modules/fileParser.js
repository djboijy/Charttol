﻿// Тут нам потрібна бібліотека XLSX i Papaparse для парсингу файлів
import Papa from 'papaparse';
import * as XLSX from 'xlsx';

// Функція для обробки завантаженого файлу
export function handleFileUpload(file) {
    return new Promise((fulfill, reject) => {
        const fileReader = new FileReader(); //file reader

        fileReader.onload = (event) => {
            const content = event.target.result;
            const fileExtension = file.name.split('.').pop().toLowerCase();

            if (fileExtension === 'csv') { // обробка CSV
                fulfill(parseCSV(content));
            } else if (fileExtension === 'json') { // обробка JSON
                fulfill(parseJSON(content));
            } else if (fileExtension === 'xls' || fileExtension === 'xlsx') { // обробка файлів Excel(2 можливих рохшир.)
                const arrayBuffer = event.target.result;
                fulfill(parseExcel(arrayBuffer));
            } else { // Помилка, якщо неправильний формат
                reject('Unsupported file format! Try again.');
                alert('Unsupported file format! Try again.');
            }
        };

        fileReader.onerror = () => {
            reject('Error reading file! Try again, please.');
            alert('Error reading file! Try again, please.');
        };

        // Код для парсингу рідером
        if (file.name.endsWith('.xls') || file.name.endsWith('.xlsx')) {
            fileReader.readAsArrayBuffer(file);
        } else {
            fileReader.readAsText(file);
        }
    });
}

// Для парсингу CSV
function parseCSV(data) {
    return new Promise((fulfill, reject) => {
        Papa.parse(data, {
            header: true,
            skipEmptyLines: true,

            fulfill: (results) => {
                const labels = results.data.map(row => row.label || row.name);
                const values = results.data.map(row => parseFloat(row.value || row.data));

                fulfill({ labels, values });
            },

            error: (error) => {
                reject(error);
                alert(error.toString());
            },
        });
    });
}

// Для парсингу jSON
function parseJSON(data) {
    return new Promise((fulfill, reject) => {
        try {
            const foundData = JSON.parse(data);
            const foundLabels = foundData.map(item => item.label || item.name);
            const foundValues = foundData.map(item => parseFloat(item.value || item.data));

            fulfill({ foundLabels, foundValues });

        } catch (error) {
            reject('Invalid JSON format! Try again!');
            alert('Invalid JSON format! Try again!');
        }
    });
}

// Для парсингу Excel
function parseExcel(data) {
    return new Promise((resolve, reject) => {
        try {
            // З використанням XLSX бібліотеки
            const readExcelDataBuffer = XLSX.read(data, { type: 'array' });
            const sheet = readExcelDataBuffer.Sheets[readExcelDataBuffer.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

            const [header, ...dataRows] = rows;

            const labels = dataRows.map(row => row[0]);
            const values = dataRows.map(row => parseFloat(row[1]));

            resolve({ labels, values });

        } catch (error) {
            reject('Failed to parse Excel file!');
            alert('Failed to parse Excel file!');
        }
    });
}

