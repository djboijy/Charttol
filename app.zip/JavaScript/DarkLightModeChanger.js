﻿const toggleButton = document.getElementById("theme-button");

function ToggleDarkMode() {
    document.body.classList.toggle("dark-mode");

    const headerElements = [
        document.getElementById("web-title"),
        document.getElementById("page-header"),
        document.getElementById("page-header2"),
        document.getElementById("page-header3"),
        document.getElementById("data-chart-final-text")
    ];

    const background = document.getElementById("page-content");
    const chartOptions = document.getElementById("chart-options");
    const dropArea = document.getElementById("drop-area");
    const textInputs = document.querySelectorAll("input[type='text'], textarea, select");
    const buttons = document.querySelectorAll(".button");
    const chartDisplaySection = document.getElementById("chart-display");

    headerElements.forEach(element => element?.classList.toggle("dark-mode-header"));
    background?.classList.toggle("file-upload-dark-mode");
    chartOptions?.classList.toggle("dark-mode-background");
    dropArea?.classList.toggle("dark-mode-background");
    chartDisplaySection?.classList.toggle("dark-mode-background");

    buttons.forEach(button => {
        button.classList.toggle("dark-mode-background");
    });

    textInputs.forEach(input => {
        input.classList.toggle("dark-mode-input");
    });

    // Debugging
    console.log("Dark Mode Applied:", document.body.classList.contains("dark-mode"));

    if (document.body.classList.contains("dark-mode")) {
        toggleButton.innerHTML = "brightness_7";
        document.body.style.background = "linear-gradient(90deg, #000000, #373739)";
    } else {
        toggleButton.innerHTML = "brightness_4";
        document.body.style.background = "linear-gradient(90deg, #0b7fe6, #08a4e6)";
    }
}

toggleButton.onclick = ToggleDarkMode;
