﻿const fileInput = document.getElementById("file-insert");
const manualDataInput = document.getElementById("manualData");
const nextButton = document.getElementById("next-button");
const cancelButton = document.getElementById("cancel-button");
const chosenFileDisplay = document.getElementById("chosen-file");
const fileChosenText = document.getElementById("file-chosen-text");

window.onload = function () {
    loadManualData();
    checkData();
};

function loadManualData() {
    const savedData = sessionStorage.getItem("manualData");
    if (savedData) {
        manualDataInput.value = savedData;
    }
}

function checkData() {
    const fileSelected = fileInput.files.length > 0;
    const manualDataFilled = manualDataInput.value.trim() !== "";

    manualDataInput.disabled = fileSelected;
    nextButton.disabled = !fileSelected && !manualDataFilled;
    cancelButton.style.display = fileSelected || manualDataFilled ? "block" : "none";
    fileChosenText.style.display = fileSelected ? "block" : "none";
}


fileInput.addEventListener("change", () => {
    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const fileName =
            file.name.length > 20
                ? file.name.slice(0, 17) + "..." + file.name.split(".").pop()
                : file.name;
        chosenFileDisplay.textContent = fileName;
        sessionStorage.setItem("uploadedFile", file.name);
    } else {
        chosenFileDisplay.textContent = "";
        sessionStorage.removeItem("uploadedFile");
    }
    checkData();
});


manualDataInput.addEventListener("input", () => {
    sessionStorage.setItem("manualData", manualDataInput.value);
    checkData();
});

nextButton.addEventListener("click", () => {
    const manualData = manualDataInput.value
        .trim()
        .split("\n")
        .reduce(
            (acc, line) => {
                const parts = line.split(":").map((item) => item.trim());
                if (parts.length === 2 && parts[0] && parts[1] && !isNaN(parts[1])) {
                    acc.labels.push(parts[0]);
                    acc.values.push(Number(parts[1]));
                }
                return acc;
            },
            { labels: [], values: [] }
        );

    sessionStorage.setItem("manualDataDict", JSON.stringify(manualData));

    window.location.href = "../Assets/HTMLPages/page2.html";
});

cancelButton.addEventListener("click", () => {
    fileInput.value = "";
    manualDataInput.value = "";
    chosenFileDisplay.textContent = "";
    sessionStorage.removeItem("manualData");
    sessionStorage.removeItem("manualDataDict");
    sessionStorage.removeItem("uploadedFile");
    checkData();
});
