window.onload = function () {

    const data = localStorage.getItem("chartData");
    if (data) {
        renderChart(data);
    } else {
        alert("No data found!");
    }

    document.getElementById('back-button').addEventListener('click', function () {
        window.location.href = '../../Assets/HTMLPages/page3.html';
    });
};

function renderChart(data) {
    const ctx = document.getElementById('chart').getContext('2d');
    const chartData = {
        labels: data.labels,
        datasets: [{
            label: 'Data from File',
            data: data.values,
            borderColor: 'rgba(75, 192, 192, 1)',
            tension: 0.1,
        }],
    };

    new Chart(ctx, {
        type: 'line',
        data: chartData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                },
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false,
            },
            scales: {
                x: {
                    type: 'category',
                },
                y: {
                    beginAtZero: true,
                },
            },
        },
    });
}

