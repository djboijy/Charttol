﻿let inputData = "";

// Отримуємо елемент поля вводу за його ID
const inputField = document.getElementById('chart-title');

// Перевіряємо, чи елемент існує на сторінці
if (inputField) {
    // Додаємо event на вводі тексту
    inputField.addEventListener('input', function(event) {
        // Оновлюємо змінну inputData значенням, введеним користувачем
        inputData = event.target.value;
        // Зберігаємо введене значення у sessionStorage
        sessionStorage.setItem('TitleOutput', inputData);
    });
} else {
    // Якщо елемент не знайдений, виводимо помилку в консоль
    console.error("Input field not found.");
}
