﻿// Викор. деякі сторонні джерела, але код зрозумів.

const fileInput = document.getElementById("file-insert");
const manualDataInput = document.getElementById("manualData");
const nextButton = document.getElementById("next-button");
const cancelButton = document.getElementById("cancel-button");
const chosenFileDisplay = document.getElementById("chosen-file");
const fileChosenText = document.getElementById("file-chosen-text");

window.onload = function () {
    loadManualData();
    checkData();
};

function loadManualData() {
    const savedData = sessionStorage.getItem("manualData");
    if (savedData) {
        manualDataInput.value = savedData;
    }
}

function checkData() {
    const fileSelected = fileInput.files.length > 0;
    const manualDataFilled = manualDataInput.value.trim() !== "";

    if (fileSelected) {
        manualDataInput.value = "";
        sessionStorage.removeItem("manualData");
    }

    manualDataInput.disabled = fileSelected;
    nextButton.disabled = !fileSelected && !manualDataFilled;
    cancelButton.style.display = fileSelected || manualDataFilled ? "block" : "none";
    fileChosenText.style.display = fileSelected ? "block" : "none";
}

fileInput.addEventListener("change", () => {
    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const fileName =
            file.name.length > 20
                ? file.name.slice(0, 17) + "..." + file.name.split(".").pop()
                : file.name;
        chosenFileDisplay.textContent = fileName;
        sessionStorage.setItem("uploadedFile", file.name);

        manualDataInput.value = "";
        sessionStorage.removeItem("manualData");
    } else {
        chosenFileDisplay.textContent = "";
        sessionStorage.removeItem("uploadedFile");
    }
    checkData();
});

manualDataInput.addEventListener("input", () => {
    sessionStorage.setItem("manualData", manualDataInput.value);
    checkData();
});

nextButton.addEventListener("click", () => {
    const manualData = manualDataInput.value
        .trim()
        .split("\n")
        .reduce(
            (acc, line) => {
                const parts = line.split(":").map((item) => item.trim());
                if (parts.length === 2 && parts[0] && parts[1] && !isNaN(parts[1])) {
                    acc.labels.push(parts[0]);
                    acc.values.push(Number(parts[1]));
                }
                return acc;
            },
            { labels: [], values: [] }
        );

    sessionStorage.setItem("manualDataDict", JSON.stringify(manualData));

    window.location.href = "../Assets/HTMLPages/page2.html";
});

cancelButton.addEventListener("click", () => {
    fileInput.value = "";
    manualDataInput.value = "";
    chosenFileDisplay.textContent = "";
    sessionStorage.removeItem("manualData");
    sessionStorage.removeItem("manualDataDict");
    sessionStorage.removeItem("uploadedFile");
    checkData();
});

document.getElementById("file-insert").addEventListener("change", (event) => {
    const file = event.target.files[0];

    if (file) {
        handleFileUpload(file)
            .then((data) => {
                localStorage.setItem("chartData", JSON.stringify(data));
                sessionStorage.setItem("fileSelected", "true");
            })
            .catch((error) => {
                alert(error);
                sessionStorage.setItem("fileSelected", "false");
            });
    } else {
        sessionStorage.setItem("fileSelected", "false");
    }
});

function handleFileUpload(file) {
    return new Promise((resolve, reject) => {
        const fileReader = new FileReader();

        fileReader.onload = (event) => {
            const content = event.target.result;
            const fileExtension = file.name.split('.').pop().toLowerCase();

            if (fileExtension === 'csv') {
                resolve(parseCSV(content));
            } else if (fileExtension === 'json') {
                resolve(parseJSON(content));
            } else if (fileExtension === 'xls' || fileExtension === 'xlsx') {
                resolve(parseExcel(content));
            } else {
                reject('Unsupported file format! Please upload CSV, JSON, or Excel files.');
            }
        };

        fileReader.onerror = () => {
            reject('Error reading file! Please try again.');
        };

        if (file.name.endsWith('.xls') || file.name.endsWith('.xlsx')) {
            fileReader.readAsArrayBuffer(file);
        } else {
            fileReader.readAsText(file);
        }
    });
}

function parseCSV(data) {
    return new Promise((resolve, reject) => {
        Papa.parse(data, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
                const labels = results.data.map(row => row.label || row.name);
                const values = results.data.map(row => parseFloat(row.value || row.data));
                resolve({ labels, values });
            },
            error: (error) => reject(error),
        });
    });
}

function parseJSON(data) {
    return new Promise((resolve, reject) => {
        try {
            const jsonData = JSON.parse(data);
            const labels = jsonData.map(item => item.label || item.name);
            const values = jsonData.map(item => parseFloat(item.value || item.data));
            resolve({ labels, values });

            sessionStorage.setItem("chartData", JSON.stringify({ values, labels }));

        } catch (error) {
            reject('Invalid JSON format!');
        }
    });
}

function parseExcel(data) {
    return new Promise((resolve, reject) => {
        try {
            const workbook = XLSX.read(data, { type: 'array' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

            const [header, ...dataRows] = rows;
            const labels = dataRows.map(row => row[0]);
            const values = dataRows.map(row => parseFloat(row[1]));
            resolve({ labels, values });
        } catch (error) {
            reject('Failed to parse Excel file!');
        }
    });
}
