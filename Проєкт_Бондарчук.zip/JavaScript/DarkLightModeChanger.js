﻿const toggleButton = document.getElementById("theme-button");

function ToggleDarkMode() {
    document.body.classList.toggle("dark-mode");

    const headerElements = [
        document.getElementById("web-title"),
        document.getElementById("page-header"),
        document.getElementById("page-header2"),
        document.getElementById("page-header3"),
        document.getElementById("data-chart-final-text")
    ];

    const bg = document.getElementById("page-content");
    const chartOptions = document.getElementById("chart-options");
    const dropfileThing = document.getElementById("drop-area");
    const textInputs = document.querySelectorAll("input[type='text'], textarea, select");
    const buttons = document.querySelectorAll(".button");
    const chartDisplay = document.getElementById("chart-display");

    headerElements.forEach(element => element.classList.toggle("dark-mode-header"));
    bg.classList.toggle("file-upload-dark-mode");
    chartOptions.classList.toggle("dark-mode-bg");
    dropfileThing.classList.toggle("dark-mode-bg");
    chartDisplay.classList.toggle("dark-mode-bg");

    buttons.forEach(button => {
        button.classList.toggle("dark-mode-bg");
    });

    textInputs.forEach(input => {
        input.classList.toggle("dark-mode-input");
    });

    console.log("Dark Mode Applied!");

    if (document.body.classList.contains("dark-mode")) {
        toggleButton.innerHTML = "brightness_7";
        document.body.style.background = "linear-gradient(90deg, #000000, #373739)";
        localStorage.setItem("darkMode", "enabled"); // збереження
    } else {
        toggleButton.innerHTML = "brightness_4";
        document.body.style.background = "linear-gradient(90deg, #0b7fe6, #08a4e6)";
        localStorage.setItem("darkMode", "disabled");
    }
}

function CheckTheme() {
    const darkmd = localStorage.getItem("darkMode");

    if (darkmd === "enabled") {
        document.body.classList.add("dark-mode");
        toggleButton.innerHTML = "brightness_7";
        document.body.style.background = "linear-gradient(90deg, #000000, #373739)";
    } else {
        document.body.classList.remove("dark-mode");
        toggleButton.innerHTML = "brightness_4";
        document.body.style.background = "linear-gradient(90deg, #0b7fe6, #08a4e6)";
    }
}

toggleButton.onclick = ToggleDarkMode;

window.onload = CheckTheme;
